#pragma once
#include "engineApi.hpp"
#include <cstddef>
#include <memory>
#include <string>
#include <vector>

#include <SDL.h>
#include <SDL_ttf.h>
#include <glm/glm.hpp>

#include "lighting2D.hpp"
#include "material2D.hpp"
#include "transform.hpp"

#include "layer.hpp"

#include "mesh3D.hpp"

class Camera;
class Shader;
class RenderTarget;

/// Owns the SDL window, OpenGL context, GPU render resources, and frame queues.
///
/// Create the renderer before GPU-backed resources and destroy it after them.
/// Components submit commands to this class; they should not issue raw OpenGL.
class Renderer
{
public:
    /// Creates a renderer configured for a 1280x720 PNG-capable window.
    ENGINE_API Renderer();

    /// Stores window and subsystem configuration for later initialization.
    ///
    /// @param width Initial logical window width in pixels.
    /// @param height Initial logical window height in pixels.
    /// @param frameCap Requested frame-cap metadata. Presentation is currently
    ///        controlled by vertical synchronization rather than this value.
    /// @param imageFlags SDL_image initialization flags such as IMG_INIT_PNG.
    /// @param title Window title. The pointed string must outlive the renderer.
    ENGINE_API Renderer(int width, int height, int frameCap, int imageFlags, const char* title);

    ENGINE_API bool SetWindowFullscreen(
        bool enabled
    );

    ENGINE_API bool IsWindowFullscreen() const;

    /// Releases renderer-owned GPU objects, the GL context, window, and SDL subsystems.
    ENGINE_API ~Renderer();

    Renderer(const Renderer&) = delete;
    Renderer& operator=(const Renderer&) = delete;

    /// Initializes SDL, SDL_image, SDL_ttf, an OpenGL 3.3 core context, GLAD,
    /// shaders, and the shared 2D quad mesh.
    ///
    /// @return Zero on success; a non-zero stage-specific error code on failure.
    ENGINE_API int Renderer_Init();

    /// Idempotently destroys renderer resources and shuts down SDL subsystems.
    /// GPU-backed Resource_manager instances must already have been destroyed.
    ENGINE_API void Renderer_Close();

    /// Starts a frame, updates the viewport/camera, clears buffers, and empties queues.
    ///
    /// @param clearColour Linear RGBA clear colour with components in the 0..1 range.
    ENGINE_API void BeginFrame(const glm::vec4& clearColour);

    ENGINE_API void BeginFrame(
        RenderTarget& target,
        const glm::vec4& clearColour
    );

    void beginFrameOnBoundTarget(
        int targetWidth,
        int targetHeight,
        const glm::vec4& clearColour
    );

    /// Stable-sorts and executes all submitted 2D commands using submitted lights.
    /// Call after all world objects have submitted and before drawing ImGui.
    ENGINE_API void Render2D();

    /// Swaps the SDL OpenGL window backbuffer.
    ENGINE_API void Renderer_PresentFrame();

    /// Selects the non-owned camera used by subsequent render passes.
    ///
    /// @param camera Camera that must remain alive while active; may be nullptr.
    void SetActiveCamera(Camera* camera) { activeCamera = camera; }

    /// @return The currently active non-owned camera, or nullptr.
    Camera* GetActiveCamera() const { return activeCamera; }

    /// Submits an untextured, lit quad using a Transform2D half-size.
    ///
    /// @param transform World position, half-size scale, and rotation in radians.
    /// @param colour Linear RGBA colour with components in the 0..1 range.
    /// @param renderLayer Primary stable-sort layer; larger layers draw later.
    ENGINE_API void SubmitSolidQuad2D(
        const Transform2D& transform,
        const glm::vec4& colour,
        int renderLayer = 0,
        int objectLayer = 0
    );  

    /// Submits a textured 2D material command.
    ///
    /// @param transform World position, half-size scale, and rotation in radians.
    /// @param material Resolved GPU texture objects and material properties.
    ENGINE_API void SubmitSprite2D(
        const Transform2D& transform,
        const Material2DRenderState& material,
        int objectLayer = 0
    );


    /// Submits an unlit line-loop around a transformed quad.
    ///
    /// @param transform World position, half-size scale, and rotation in radians.
    /// @param colour Linear RGBA outline colour in the 0..1 range.
    /// @param renderLayer Primary stable-sort layer; larger layers draw later.
    ENGINE_API void SubmitOutline2D(
        const Transform2D& transform,
        const glm::vec4& colour,
        int renderLayer = 0,
        int objectLayer = 0
    );

    /// Adds a point light to the current frame, up to the sixteen-light limit.
    /// Extra lights are ignored until a later frame.
    ///
    /// @param light World-space point-light data. Shadow flags are currently reserved.
    ENGINE_API void SubmitLight2D(
        const PointLight2D& light,
        int objectLayer = 0
    );

    ENGINE_API void SubmitMesh3D(
        const MeshRenderState& mesh,
        const glm::mat4& worldMatrix,
        const glm::vec4& colour,
        int objectLayer = 0
    );

    /// Submits a mesh silhouette shell rendered through the 3D outline pass.
    ENGINE_API void SubmitSelectionOutline3D(
        const MeshRenderState& mesh,
        const glm::mat4& worldMatrix,
        const glm::vec4& colour,
        float shellScale = 1.04f,
        int objectLayer = 0
    );

    ENGINE_API void Render3D();

    /// Builds a transient OpenGL text texture and submits it as an unlit quad.
    ///
    /// The command must be submitted before Render2D(). The transient texture is
    /// deleted after that render pass.
    ///
    /// @param text UTF-8 text to render.
    /// @param font Non-owned, open SDL_ttf font.
    /// @param source Reserved source rectangle; currently ignored.
    /// @param destination Optional screen/world rectangle; surface size is used when null.
    /// @param textColour SDL byte-range text colour.
    void Renderer_ttf(
        const std::string& text,
        TTF_Font* font,
        SDL_Rect* source,
        SDL_Rect* destination,
        SDL_Color& textColour
    );

    /// @return The renderer-owned SDL window.
    SDL_Window* get_SDLWindow() const { return window; }

    /// @return The renderer-owned SDL OpenGL context.
    SDL_GLContext get_GLContext() const { return glContext; }

    /// @return Current logical window width in pixels.
    int get_screen_width() const { return screenWidth; }

    /// @return Current logical window height in pixels.
    int get_screen_height() const { return screenHeight; }

private:
    enum class CommandType2D
    {
        Quad,
        Outline
    };

    struct RenderCommand2D
    {
        CommandType2D type = CommandType2D::Quad;
        Transform2D transform;
        Material2DRenderState material;
        std::size_t submissionOrder = 0;
        bool deleteAlbedoAfterDraw = false;
    };

    struct RenderCommand3D
    {
        unsigned int vertexArray = 0;
        std::size_t indexCount = 0;

        glm::mat4 worldMatrix =
            glm::mat4(1.0f);

        glm::vec4 colour =
            glm::vec4(1.0f);
    };

    struct SelectionOutlineCommand3D
    {
        unsigned int vertexArray = 0;
        std::size_t indexCount = 0;

        glm::mat4 worldMatrix =
            glm::mat4(1.0f);

        glm::vec4 colour =
            glm::vec4(1.0f);

        float shellScale = 1.04f;
    };

    bool initialise3DRenderer();
    void destroy3DRenderer();
    bool initialiseOpenGLContext();
    bool initialise2DRenderer();
    void destroy2DRenderer();
    void drawCommand2D(const RenderCommand2D& command);
    void uploadLights2D();
    bool shouldRenderLayer(int objectLayer) const;

    bool initialised = false;
    SDL_Window* window = nullptr;
    SDL_GLContext glContext = nullptr;

    const char* title = "SDL2 Game Engine";
    int screenWidth = 1280;
    int screenHeight = 720;
    int frameCap = 60;
    int imageFlags = 0;
    bool windowFullscreen = false;

    unsigned int quadVertexArray = 0;
    unsigned int quadVertexBuffer = 0;
    unsigned int quadIndexBuffer = 0;
    std::unique_ptr<Shader> spriteShader;

    Camera* activeCamera = nullptr;
    std::vector<RenderCommand2D> renderCommands2D;
    std::vector<PointLight2D> lights2D;
    std::size_t nextSubmissionOrder = 0;
    
    std::unique_ptr<Shader> meshShader;
    std::unique_ptr<Shader> meshOutlineShader;
    std::vector<RenderCommand3D> renderCommands3D;
    std::vector<SelectionOutlineCommand3D> selectionOutlineCommands3D;
};
