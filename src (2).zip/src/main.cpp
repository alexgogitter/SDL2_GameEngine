#include <algorithm>
#include <cstdint>

#include <SDL.h>
#include <SDL_image.h>

#include "eventListener.hpp"
#include "interfaceImplementation.hpp"
#include "render.hpp"
#include "resource_manager.hpp"
#include "time.hpp"

#include <cassert>
#include <cstring>

#include <imgui.h>

#include "builtInComponents.hpp"
#include "editorSelection.hpp"
#include "layerRegistry.hpp"
#include "objectInspector.hpp"
#include "componentInspector.hpp"
#include "componentRegistry.hpp"
#include "object.hpp"
#include "scene.hpp"
#include "sceneHierarchy.hpp"

#include "physxContext.hpp"
#include "physicsWorld2D.hpp"
#include "physicsWorld3D.hpp"

#include "cameraComponent.hpp"
#include "cameraSystem.hpp"

#include "cameraOutputPanel.hpp"
#include "gameViewPanel.hpp"
#include "renderTarget.hpp"
#include "editorCamera.hpp"
#include "meshFilterComponent.hpp"
#include "sceneViewPanel.hpp"
#include "editorPlayState.hpp"
#include "editorPlayToolbar.hpp"
#include "editorPlaySnapshot.hpp"

namespace
{
    void SubmitSelectedObjectOutline(
        Renderer& renderer,
        Resource_manager& resources,
        Scene& scene,
        EditorSelection& selection
    )
    {
        Object* selected =
            selection.getSelectedObject(scene);

        if (selected == nullptr || !selected->isActive())
        {
            return;
        }

        MeshFilterComponent* filter =
            selected->getComponent<
                MeshFilterComponent
            >();

        if (filter == nullptr)
        {
            return;
        }

        MeshRenderState mesh;

        if (!resources.getMeshRenderState(filter->getMesh(), mesh))
        {
            return;
        }

        renderer.SubmitSelectionOutline3D(
            mesh,
            selected->getWorldMatrix(),
            glm::vec4(
                0.97f,
                0.63f,
                0.16f,
                1.0f
            ),
            1.05f,
            selected->getLayer()
        );
    }
}

int main(int, char**)
{

    Renderer renderer(
        1600,
        900,
        60,
        IMG_INIT_PNG,
        "Game Engine"
    );
    if (renderer.Renderer_Init() != 0)
    {
        return 1;
    }

    PhysXContext physxContext;

    if (!physxContext.isValid())
    {
        renderer.Renderer_Close();
        return 2;
    }
    PhysicsWorld3D physicsWorld(physxContext);

    PhysicsWorld2D physicsWorld2D(physxContext);

    if (!physicsWorld.isValid() || !physicsWorld2D.isValid())
    {
        renderer.Renderer_Close();
        return 3;
    }

    Interface* interface = Interface::create(
        renderer.get_SDLWindow(),
        renderer.get_GLContext()
    );
    if (interface == nullptr)
    {
        return 4;
    }

    {
        Resource_manager resources;
        ComponentRegistry componentRegistry;
        const bool componentsRegistered =
            RegisterBuiltInComponents(componentRegistry);

        Scene editorScene(resources, renderer);
        LayerRegistry editorLayers;
        EditorSelection editorSelection;
        CameraSystem cameraSystem;

        RenderTarget gameViewTarget(960, 540);
        GameViewPanelState gameViewPanelState;
        RenderTarget sceneViewTarget(960, 540);
        SceneViewPanelState sceneViewPanelState;
        EditorCamera editorCamera(960.0f, 540.0f);

        EditorPlayState editorPlayState;
        EditorPlaySnapshot editorPlaySnapshot;

        Object* inspectorLightObject = editorScene.createObject("Inspector Light");

        Component* inspectorLightComponent = nullptr;

        if (componentsRegistered && inspectorLightObject != nullptr)
        {
            // Prevent the light object itself from drawing a fallback quad.
            inspectorLightObject->draw_colour.a = 0.0f;

            ComponentCreateContext context;
            context.physicsWorld3D = &physicsWorld;
            context.resources = &resources;
            context.renderer = &renderer;

            inspectorLightComponent = componentRegistry.createAndAttach("PointLight2D", *inspectorLightObject, context);
            editorSelection.selectObject(inspectorLightObject);
        }

        Object* physicsFloorObject = editorScene.createObject("Physics Floor"); 
        
        Object* physicsCubeObject = editorScene.createObject("Physics Cube");

        Object* mainCameraObject = editorScene.createObject("Main Camera");

        if (componentsRegistered && mainCameraObject != nullptr)
        {
            mainCameraObject->draw_colour.a = 0.0f;

            mainCameraObject->transform.setPosition(glm::vec3(0.0f, 4.0f, 10.0f));

            mainCameraObject->transform.setEulerRadians(glm::vec3(
                    glm::radians(-20.0f),
                    0.0f,
                    0.0f
                )
            );

            ComponentCreateContext context;
            context.resources = &resources;
            context.renderer = &renderer;
            context.physicsWorld3D = &physicsWorld;

            componentRegistry.createAndAttach("Camera", *mainCameraObject, context);

            editorSelection.selectObject(mainCameraObject);
        }

        if (mainCameraObject != nullptr)
        {
            cameraSystem.setPrimaryCamera(
                editorScene,
                CameraOutputTarget::GameView,
                mainCameraObject->getId()
            );
        }

        if (componentsRegistered &&
            physicsFloorObject != nullptr
        )
        {
            // Prevent the legacy fallback quad.
            physicsFloorObject->
                draw_colour.a = 0.0f;

            physicsFloorObject->
                transform.setPosition(
                    glm::vec3(
                        0.0f,
                        -1.0f,
                        0.0f
                    )
                );

            physicsFloorObject->
                transform.setScale(
                    glm::vec3(
                        12.0f,
                        0.5f,
                        12.0f
                    )
                );

            ComponentCreateContext context;
            context.resources = &resources;
            context.renderer = &renderer;
            context.physicsWorld3D =
                &physicsWorld;

            componentRegistry.createAndAttach(
                "MeshFilter3D",
                *physicsFloorObject,
                context
            );

            componentRegistry.createAndAttach(
                "MeshRenderer3D",
                *physicsFloorObject,
                context
            );

            // No Rigidbody3D is attached. BoxCollider3D
            // therefore creates a static PhysX actor.
            componentRegistry.createAndAttach(
                "BoxCollider3D",
                *physicsFloorObject,
                context
            );
        }

        if (componentsRegistered && physicsCubeObject != nullptr)
        {
            // MeshFilter does not render by itself. Prevent the
            // object's legacy fallback 2D quad from appearing.
            physicsCubeObject->draw_colour.a = 0.0f;
            
            ComponentCreateContext context;
            context.resources = &resources;
            context.renderer = &renderer;
            context.physicsWorld3D = &physicsWorld;

            physicsCubeObject->transform.setPosition(
                glm::vec3(0.0f, 5.0f, 0.0f)
            );

            componentRegistry.createAndAttach(
                "MeshFilter3D",
                *physicsCubeObject,
                context
            );

            componentRegistry.createAndAttach(
                "MeshRenderer3D",
                *physicsCubeObject,
                context
            );

            componentRegistry.createAndAttach(
                "Rigidbody3D",
                *physicsCubeObject,
                context
            );

            componentRegistry.createAndAttach(
                "BoxCollider3D",
                *physicsCubeObject,
                context
            );

            editorSelection.selectObject(
                physicsCubeObject
            );

            

        }

        ComponentCreateContext editorComponentContext;
        editorComponentContext.resources = &resources;
        editorComponentContext.physicsWorld = &physicsWorld2D;
        editorComponentContext.physicsWorld3D = &physicsWorld;
        editorComponentContext.renderer = &renderer;

        Time frameTimer;
        std::uint64_t frameDeltaMs = 16;

        interface->addDrawCallback(
            [
                &editorScene,
                &editorSelection,
                &editorLayers,
                &cameraSystem,
                &gameViewTarget,
                &gameViewPanelState,
                &sceneViewTarget,
                &sceneViewPanelState,
                &editorCamera,
                &editorPlayState,
                &componentRegistry,
                &editorComponentContext
            ]()
            {
                if (gameViewPanelState.fullscreen)
                {
                    DrawGameViewPanel(gameViewTarget, gameViewPanelState);
                    return;
                }

                DrawEditorPlayToolbar(editorPlayState);

                ImGui::Begin("Hierarchy");
                DrawSceneHierarchy(editorScene, editorSelection);
                ImGui::End();

                DrawCameraOutputPanel(cameraSystem, editorScene);

                ImGui::Begin("Inspector");

                Object* selected = editorSelection.getSelectedObject(editorScene);

                if (selected != nullptr)
                {
                    DrawObjectInspector(*selected, editorLayers, componentRegistry, editorComponentContext, editorPlayState.isEditing());
                }
                else
                {
                    ImGui::TextDisabled("No object selected");
                }

                ImGui::End();

                DrawGameViewPanel(gameViewTarget, gameViewPanelState);

                DrawSceneViewPanel(sceneViewTarget, editorCamera, editorScene, editorSelection, sceneViewPanelState);
            }
        );

        bool quit = false;
        SDL_Event event;
        EventListener& input = EventListener::Get();

        while (!quit)
        {
            frameTimer.tick();
            input.BeginFrame();

            while (SDL_PollEvent(&event) != 0)
            {
                input.ProcessEvent(event);
                interface->update(event);           

                if (event.type == SDL_QUIT)
                {
                    quit = true;
                }
            }
            if (
                    input.WasKeyPressed(
                        SDL_SCANCODE_F11
                    )
                )
                {
                    const bool requestedFullscreen =
                        !gameViewPanelState.fullscreen;

                    if (
                        renderer.SetWindowFullscreen(
                            requestedFullscreen
                        )
                    )
                    {
                        gameViewPanelState.fullscreen =
                            requestedFullscreen;
                    }
                }

                if (
                    input.WasKeyPressed(
                        SDL_SCANCODE_ESCAPE
                    )
                )
                {
                    if (gameViewPanelState.fullscreen)
                    {
                        if (
                            renderer.SetWindowFullscreen(
                                false
                            )
                        )
                        {
                            gameViewPanelState.fullscreen =
                                false;
                        }
                    }
                    else
                    {
                        quit = true;
                    }
                }

            const float deltaSeconds =
                static_cast<float>(std::min<std::uint64_t>(frameDeltaMs, 50)) /
                1000.0f;

            sceneViewTarget.resize(
                sceneViewPanelState.requestedWidth,
                sceneViewPanelState.requestedHeight
            );

            gameViewTarget.resize(
                gameViewPanelState.requestedWidth,
                gameViewPanelState.requestedHeight
            );
            editorCamera.update(
                input,
                sceneViewPanelState.hovered,
                deltaSeconds
            );

            if (
                sceneViewPanelState.hovered &&
                input.WasKeyPressed(SDL_SCANCODE_F)
            )
            {
                Object* selected =
                    editorSelection.getSelectedObject(
                        editorScene
                    );

                if (selected != nullptr)
                {
                    editorCamera.focus(
                        selected->getWorldPosition(),
                        10.0f
                    );
                }
            }

            const bool advanceSingleFrame = editorPlayState.consumeSingleStepRequest();

            if (
                editorPlayState.isPlaying() ||
                advanceSingleFrame
            )
            {
                const float simulationDelta =
                    advanceSingleFrame
                        ? PhysicsWorld3D::FixedTimeStep
                        : deltaSeconds;

                physicsWorld.Step(simulationDelta);

                const std::uint64_t simulationDeltaMs =
                    advanceSingleFrame
                        ? static_cast<std::uint64_t>(
                            PhysicsWorld3D::FixedTimeStep *
                            1000.0f
                        )
                        : frameDeltaMs;

                editorScene.update(
                    simulationDeltaMs
                );
            }

            renderer.SetActiveCamera(
                &editorCamera.getCamera()
            );

            renderer.BeginFrame(
                sceneViewTarget,
                glm::vec4(
                    0.055f,
                    0.070f,
                    0.095f,
                    1.0f
                )
            );

            editorScene.draw();

            SubmitSelectedObjectOutline(
                renderer,
                resources,
                editorScene,
                editorSelection
            );

            // Opaque 3D geometry first, editor overlays second.
            renderer.Render3D();
            renderer.Render2D();

            glm::vec4 gameClearColour(
                0.012f,
                0.018f,
                0.030f,
                1.0f
            );

            CameraComponent* gameOutputCamera = cameraSystem.resolvePrimaryCamera(editorScene, CameraOutputTarget::GameView);

            if (gameOutputCamera != nullptr)
            {
                gameClearColour =
                    gameOutputCamera->getClearColour();
            }

            renderer.SetActiveCamera(
                gameOutputCamera
            );

            renderer.BeginFrame(
                gameViewTarget,
                gameClearColour
            );

            editorScene.draw();

            // The Game View now uses the selected hierarchy camera.
            renderer.Render3D();
            renderer.Render2D();


            // The backbuffer contains editor UI, so it must not
            // alter either the Game View or Scene View camera.
            renderer.SetActiveCamera(nullptr);

            renderer.BeginFrame({
                0.035f,
                0.040f,
                0.050f,
                1.0f
            });

            const EditorPlayMode modeBeforeEditorDraw = editorPlayState.getMode();

            interface->draw();

            const EditorPlayMode modeAfterEditorDraw = editorPlayState.getMode();

            if (modeBeforeEditorDraw == EditorPlayMode::Edit &&
                modeAfterEditorDraw == EditorPlayMode::Playing)
            {
                editorPlaySnapshot.capture(editorScene);
            }
            else if (modeBeforeEditorDraw != EditorPlayMode::Edit &&
                modeAfterEditorDraw == EditorPlayMode::Edit)
            {
                editorPlaySnapshot.restore(editorScene                );
            }

            renderer.Renderer_PresentFrame();

            frameDeltaMs = frameTimer.tock();
        }
    }

    delete interface;
    renderer.Renderer_Close();
    return 0;
}
