#include "render.hpp"

#include <algorithm>
#include <cstdio>
#include <iostream>
#include <string>

#include <SDL_image.h>
#include <glad/glad.h>
#include <glm/gtc/matrix_transform.hpp>

#include "renderTarget.hpp"
#include "camera.hpp"
#include "shader.hpp"

namespace
{
    constexpr int MaximumPointLights2D = 16;

    glm::mat4 buildModelMatrix(const Transform2D& transform)
    {
        glm::mat4 model(1.0f);
        model = glm::translate(
            model,
            glm::vec3(transform.getPosition(), 0.0f)
        );
        model = glm::rotate(
            model,
            transform.getRotation(),
            glm::vec3(0.0f, 0.0f, 1.0f)
        );
        model = glm::scale(
            model,
            glm::vec3(transform.getScale() * 2.0f, 1.0f)
        );
        return model;
    }

    unsigned int uploadSurfaceTexture(SDL_Surface* sourceSurface)
    {
        if (sourceSurface == nullptr)
        {
            return 0;
        }

        SDL_Surface* surface = SDL_ConvertSurfaceFormat(
            sourceSurface,
            SDL_PIXELFORMAT_RGBA32,
            0
        );
        if (surface == nullptr)
        {
            return 0;
        }

        unsigned int texture = 0;
        glGenTextures(1, &texture);
        glBindTexture(GL_TEXTURE_2D, texture);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            GL_RGBA8,
            surface->w,
            surface->h,
            0,
            GL_RGBA,
            GL_UNSIGNED_BYTE,
            surface->pixels
        );
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glBindTexture(GL_TEXTURE_2D, 0);

        SDL_FreeSurface(surface);
        return texture;
    }
}

Renderer::Renderer()
    : Renderer(1280, 720, 60, IMG_INIT_PNG, "SDL2 Game Engine")
{
}

Renderer::Renderer(
    int width,
    int height,
    int requestedFrameCap,
    int requestedImageFlags,
    const char* requestedTitle)
    : title(requestedTitle),
      screenWidth(width),
      screenHeight(height),
      frameCap(requestedFrameCap),
      imageFlags(requestedImageFlags)
{
}

Renderer::~Renderer()
{
    Renderer_Close();
}

int Renderer::Renderer_Init()
{
    if (initialised)
    {
        return 0;
    }

    if (SDL_Init(SDL_INIT_VIDEO) != 0)
    {
        std::fprintf(stderr, "Unable to initialise SDL: %s\n", SDL_GetError());
        return 1;
    }

    if ((IMG_Init(imageFlags) & imageFlags) != imageFlags)
    {
        std::fprintf(stderr, "Unable to initialise SDL_image: %s\n", IMG_GetError());
        return 2;
    }

    if (TTF_Init() != 0)
    {
        std::fprintf(stderr, "Unable to initialise SDL_ttf: %s\n", TTF_GetError());
        return 3;
    }

    if (!initialiseOpenGLContext())
    {
        return 4;
    }

    if (!initialise2DRenderer())
    {
        Renderer_Close();
        return 5;
    }

    if (!initialise3DRenderer())
    {
        Renderer_Close();
        return 6;
    }

    initialised = true;
    return 0;
}

bool Renderer::initialiseOpenGLContext()
{
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_FRAMEBUFFER_SRGB_CAPABLE, 1);

    window = SDL_CreateWindow(
        title,
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        screenWidth,
        screenHeight,
        SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE |
            SDL_WINDOW_ALLOW_HIGHDPI
    );
    if (window == nullptr)
    {
        std::fprintf(stderr, "Unable to create SDL OpenGL window: %s\n", SDL_GetError());
        return false;
    }

    glContext = SDL_GL_CreateContext(window);
    if (glContext == nullptr)
    {
        std::fprintf(stderr, "Unable to create OpenGL context: %s\n", SDL_GetError());
        return false;
    }

    SDL_GL_MakeCurrent(window, glContext);
    if (!gladLoadGLLoader(reinterpret_cast<GLADloadproc>(SDL_GL_GetProcAddress)))
    {
        std::fprintf(stderr, "Unable to load OpenGL functions through GLAD.\n");
        return false;
    }

    SDL_GL_SetSwapInterval(1);

    std::cout << "OpenGL renderer: " << glGetString(GL_RENDERER) << '\n'
              << "OpenGL version: " << glGetString(GL_VERSION) << '\n';
    return true;
}

bool Renderer::initialise2DRenderer()
{
    spriteShader = std::make_unique<Shader>();
    if (!spriteShader->loadFromFiles(
            "res/shaders/sprite2d.vert",
            "res/shaders/sprite2d.frag"))
    {
        return false;
    }

    const float vertices[] = {
        -0.5f, -0.5f, 0.0f, 0.0f,
         0.5f, -0.5f, 1.0f, 0.0f,
         0.5f,  0.5f, 1.0f, 1.0f,
        -0.5f,  0.5f, 0.0f, 1.0f
    };
    const unsigned int indices[] = {0, 1, 2, 0, 2, 3};

    glGenVertexArrays(1, &quadVertexArray);
    glGenBuffers(1, &quadVertexBuffer);
    glGenBuffers(1, &quadIndexBuffer);

    glBindVertexArray(quadVertexArray);
    glBindBuffer(GL_ARRAY_BUFFER, quadVertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, quadIndexBuffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), nullptr);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(
        1,
        2,
        GL_FLOAT,
        GL_FALSE,
        4 * sizeof(float),
        reinterpret_cast<void*>(2 * sizeof(float))
    );
    glBindVertexArray(0);

    spriteShader->use();
    spriteShader->setInt("uAlbedoTexture", 0);
    spriteShader->setInt("uNormalTexture", 1);
    spriteShader->setInt("uHeightTexture", 2);
    spriteShader->setInt("uEmissionTexture", 3);
    spriteShader->setInt("uDiffuseTexture", 4);
    spriteShader->setInt("uSpecularTexture", 5);
    spriteShader->setInt("uAlphaMaskTexture", 6);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    return true;
}

void Renderer::Renderer_Close()
{
    if (glContext != nullptr)
    {
        SDL_GL_MakeCurrent(window, glContext);
        destroy2DRenderer();
        destroy3DRenderer();
    }

    if (glContext != nullptr)
    {
        SDL_GL_DeleteContext(glContext);
        glContext = nullptr;
    }

    if (window != nullptr)
    {
        SDL_DestroyWindow(window);
        window = nullptr;
    }

    if (initialised || SDL_WasInit(SDL_INIT_VIDEO) != 0)
    {
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
    }
    windowFullscreen = false;
    initialised = false;
}

void Renderer::destroy2DRenderer()
{
    for (const RenderCommand2D& command : renderCommands2D)
    {
        if (command.deleteAlbedoAfterDraw && command.material.albedoTexture != 0)
        {
            glDeleteTextures(1, &command.material.albedoTexture);
        }
    }
    renderCommands2D.clear();

    if (quadIndexBuffer != 0)
    {
        glDeleteBuffers(1, &quadIndexBuffer);
        quadIndexBuffer = 0;
    }
    if (quadVertexBuffer != 0)
    {
        glDeleteBuffers(1, &quadVertexBuffer);
        quadVertexBuffer = 0;
    }
    if (quadVertexArray != 0)
    {
        glDeleteVertexArrays(1, &quadVertexArray);
        quadVertexArray = 0;
    }

    spriteShader.reset();
}

void Renderer::BeginFrame(
    const glm::vec4& clearColour
)
{
    int drawableWidth = 0;
    int drawableHeight = 0;

    SDL_GL_GetDrawableSize(
        window,
        &drawableWidth,
        &drawableHeight
    );

    SDL_GetWindowSize(
        window,
        &screenWidth,
        &screenHeight
    );

    RenderTarget::bindDefault();

    beginFrameOnBoundTarget(
        drawableWidth,
        drawableHeight,
        clearColour
    );
}

void Renderer::BeginFrame(
    RenderTarget& target,
    const glm::vec4& clearColour
)
{
    if (!target.isValid())
    {
        BeginFrame(clearColour);
        return;
    }

    target.bind();

    beginFrameOnBoundTarget(
        target.getWidth(),
        target.getHeight(),
        clearColour
    );
}

void Renderer::beginFrameOnBoundTarget(
    int targetWidth,
    int targetHeight,
    const glm::vec4& clearColour
)
{
    targetWidth = std::max(targetWidth, 1);
    targetHeight = std::max(targetHeight, 1);

    if (activeCamera != nullptr)
    {
        activeCamera->setViewportSize(
            static_cast<float>(targetWidth),
            static_cast<float>(targetHeight)
        );
    }

    glViewport(
        0,
        0,
        targetWidth,
        targetHeight
    );

    glEnable(GL_FRAMEBUFFER_SRGB);

    glClearColor(
        clearColour.r,
        clearColour.g,
        clearColour.b,
        clearColour.a
    );

    glClear(
        GL_COLOR_BUFFER_BIT |
        GL_DEPTH_BUFFER_BIT |
        GL_STENCIL_BUFFER_BIT
    );

    renderCommands2D.clear();
    renderCommands3D.clear();
    selectionOutlineCommands3D.clear();
    lights2D.clear();
    nextSubmissionOrder = 0;
}
bool Renderer::shouldRenderLayer(int objectLayer) const
{
    if (!IsValidLayer(objectLayer))
    {
        return false;
    }

    return activeCamera == nullptr ||
        activeCamera->rendersLayer(objectLayer);
}

void Renderer::SubmitSolidQuad2D(
        const Transform2D& transform,
    const glm::vec4& colour,
    int renderLayer,
    int objectLayer)
{
    if (!shouldRenderLayer(objectLayer))
    {
        return;
    }
    Material2DRenderState material;
    material.tint = colour;
    material.lit = true;
    material.renderLayer = renderLayer;

    renderCommands2D.push_back({
        CommandType2D::Quad,
        transform,
        material,
        nextSubmissionOrder++,
        false
    });
}

void Renderer::SubmitSprite2D(
    const Transform2D& transform,
    const Material2DRenderState& material,
    int objectLayer)
{
    if (!shouldRenderLayer(objectLayer))
    {
        return;
    }
    renderCommands2D.push_back({
        CommandType2D::Quad,
        transform,
        material,
        nextSubmissionOrder++,
        false
    });
}

void Renderer::SubmitOutline2D(
    const Transform2D& transform,
    const glm::vec4& colour,
    int renderLayer,
    int objectLayer)
{
    if (!shouldRenderLayer(objectLayer))
    {
        return;
    }
    Material2DRenderState material;
    material.tint = colour;
    material.lit = false;
    material.renderLayer = renderLayer;

    renderCommands2D.push_back({
        CommandType2D::Outline,
        transform,
        material,
        nextSubmissionOrder++,
        false
    });
}

void Renderer::SubmitLight2D(
    const PointLight2D& light,
    int objectLayer)
{
    if (!shouldRenderLayer(objectLayer))
    {
        return;
    }

    if (lights2D.size() < MaximumPointLights2D)
    {
        lights2D.push_back(light);
    }
}

void Renderer::SubmitMesh3D(
    const MeshRenderState& mesh,
    const glm::mat4& worldMatrix,
    const glm::vec4& colour,
    int objectLayer
)
{
    if (
        mesh.vertexArray == 0 ||
        mesh.indexCount == 0 ||
        !shouldRenderLayer(objectLayer)
    )
    {
        return;
    }

    renderCommands3D.push_back({
        mesh.vertexArray,
        mesh.indexCount,
        worldMatrix,
        colour
    });
}

void Renderer::SubmitSelectionOutline3D(
    const MeshRenderState& mesh,
    const glm::mat4& worldMatrix,
    const glm::vec4& colour,
    float shellScale,
    int objectLayer
)
{
    if (
        mesh.vertexArray == 0 ||
        mesh.indexCount == 0 ||
        !shouldRenderLayer(objectLayer)
    )
    {
        return;
    }

    selectionOutlineCommands3D.push_back({
        mesh.vertexArray,
        mesh.indexCount,
        worldMatrix,
        colour,
        std::max(shellScale, 1.001f)
    });
}

void Renderer::Render2D()
{
    if (spriteShader == nullptr || !spriteShader->isValid())
    {
        return;
    }

    std::stable_sort(
        renderCommands2D.begin(),
        renderCommands2D.end(),
        [](const RenderCommand2D& left, const RenderCommand2D& right)
        {
            if (left.material.renderLayer == right.material.renderLayer)
            {
                return left.submissionOrder < right.submissionOrder;
            }
            return left.material.renderLayer < right.material.renderLayer;
        }
    );

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    spriteShader->use();
    const glm::mat4 viewProjection = activeCamera != nullptr
        ? activeCamera->getViewProjectionMatrix()
        : glm::ortho(
            0.0f,
            static_cast<float>(screenWidth),
            static_cast<float>(screenHeight),
            0.0f,
            -100.0f,
            100.0f
        );
    spriteShader->setMat4("uViewProjection", viewProjection);
    uploadLights2D();

    glBindVertexArray(quadVertexArray);
    for (const RenderCommand2D& command : renderCommands2D)
    {
        drawCommand2D(command);
        if (command.deleteAlbedoAfterDraw && command.material.albedoTexture != 0)
        {
            glDeleteTextures(1, &command.material.albedoTexture);
        }
    }
    glBindVertexArray(0);

    renderCommands2D.clear();
}

void Renderer::Render3D()
{
    if (
        meshShader == nullptr ||
        !meshShader->isValid() ||
        activeCamera == nullptr
    )
    {
        renderCommands3D.clear();
        selectionOutlineCommands3D.clear();
        return;
    }

    glEnable(GL_DEPTH_TEST);
    glDepthMask(GL_TRUE);
    glDepthFunc(GL_LESS);

    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);

    glDisable(GL_BLEND);

    meshShader->use();

    meshShader->setMat4(
        "uViewProjection",
        activeCamera->
            getViewProjectionMatrix()
    );

    for (
        const RenderCommand3D& command :
        renderCommands3D
    )
    {
        meshShader->setMat4(
            "uModel",
            command.worldMatrix
        );

        meshShader->setVec4(
            "uColour",
            command.colour
        );

        glBindVertexArray(
            command.vertexArray
        );

        glDrawElements(
            GL_TRIANGLES,
            static_cast<GLsizei>(
                command.indexCount
            ),
            GL_UNSIGNED_INT,
            nullptr
        );
    }

    if (
        !selectionOutlineCommands3D.empty() &&
        meshOutlineShader != nullptr &&
        meshOutlineShader->isValid()
    )
    {
        glEnable(GL_STENCIL_TEST);
        glStencilMask(0xFF);
        glStencilFunc(GL_ALWAYS, 1, 0xFF);
        glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

        // Mark the selected mesh silhouette into stencil without touching colour.
        glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
        glDepthMask(GL_FALSE);

        meshShader->use();
        meshShader->setMat4(
            "uViewProjection",
            activeCamera->getViewProjectionMatrix()
        );

        for (const SelectionOutlineCommand3D& command : selectionOutlineCommands3D)
        {
            meshShader->setMat4(
                "uModel",
                command.worldMatrix
            );

            glBindVertexArray(command.vertexArray);

            glDrawElements(
                GL_TRIANGLES,
                static_cast<GLsizei>(command.indexCount),
                GL_UNSIGNED_INT,
                nullptr
            );
        }

        // Restore colour writes and draw only shell pixels outside the marked mesh.
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        glDepthMask(GL_TRUE);
        glStencilFunc(GL_NOTEQUAL, 1, 0xFF);
        glStencilMask(0x00);
        glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

        glEnable(GL_CULL_FACE);
        glCullFace(GL_FRONT);

        meshOutlineShader->use();
        meshOutlineShader->setMat4(
            "uViewProjection",
            activeCamera->getViewProjectionMatrix()
        );

        for (const SelectionOutlineCommand3D& command : selectionOutlineCommands3D)
        {
            meshOutlineShader->setMat4(
                "uModel",
                command.worldMatrix
            );

            meshOutlineShader->setVec4(
                "uOutlineColour",
                command.colour
            );

            meshOutlineShader->setFloat(
                "uOutlineScale",
                command.shellScale
            );

            glBindVertexArray(command.vertexArray);

            glDrawElements(
                GL_TRIANGLES,
                static_cast<GLsizei>(command.indexCount),
                GL_UNSIGNED_INT,
                nullptr
            );
        }

        glCullFace(GL_BACK);
        glStencilMask(0xFF);
        glDisable(GL_STENCIL_TEST);
    }

    glBindVertexArray(0);

    glDisable(GL_CULL_FACE);
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);

    renderCommands3D.clear();
    selectionOutlineCommands3D.clear();
}

void Renderer::uploadLights2D()
{
    spriteShader->setInt("uLightCount", static_cast<int>(lights2D.size()));
    spriteShader->setVec3("uAmbientLight", glm::vec3(0.32f));

    for (std::size_t index = 0; index < lights2D.size(); ++index)
    {
        const std::string prefix = "uLights[" + std::to_string(index) + "].";
        spriteShader->setVec3(prefix + "position", lights2D[index].position);
        spriteShader->setVec3(prefix + "colour", lights2D[index].colour);
        spriteShader->setFloat(prefix + "intensity", lights2D[index].intensity);
        spriteShader->setFloat(prefix + "radius", lights2D[index].radius);
    }
}

void Renderer::drawCommand2D(const RenderCommand2D& command)
{
    spriteShader->setMat4("uModel", buildModelMatrix(command.transform));
    spriteShader->setVec4("uTint", command.material.tint);
    spriteShader->setFloat("uSpriteRotation", command.transform.getRotation());
    spriteShader->setFloat("uNormalStrength", command.material.normalStrength);
    spriteShader->setFloat("uHeightScale", command.material.heightScale);
    spriteShader->setFloat("uSpecularStrength", command.material.specularStrength);
    spriteShader->setFloat("uShininess", command.material.shininess);
    spriteShader->setVec4("uAlbedoUvRect", command.material.albedoUvRect);
    spriteShader->setVec4("uAlphaMaskUvRect", command.material.alphaMaskUvRect);
    spriteShader->setVec4("uDiffuseUvRect", command.material.diffuseUvRect);
    spriteShader->setVec4("uNormalUvRect", command.material.normalUvRect);
    spriteShader->setVec4("uHeightUvRect", command.material.heightUvRect);
    spriteShader->setVec4("uEmissionUvRect", command.material.emissionUvRect);
    spriteShader->setVec4("uSpecularUvRect", command.material.specularUvRect);
    spriteShader->setBool("uLit", command.material.lit);
    spriteShader->setBool("uHasAlbedo", command.material.albedoTexture != 0);
    spriteShader->setBool("uHasAlphaMask", command.material.alphaMaskTexture != 0);
    spriteShader->setBool("uHasDiffuse", command.material.diffuseTexture != 0);
    spriteShader->setBool("uHasNormal", command.material.normalTexture != 0);
    spriteShader->setBool("uHasHeight", command.material.heightTexture != 0);
    spriteShader->setBool("uHasEmission", command.material.emissionTexture != 0);
    spriteShader->setBool("uHasSpecular", command.material.specularTexture != 0);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, command.material.albedoTexture);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, command.material.normalTexture);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, command.material.heightTexture);
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, command.material.emissionTexture);
    glActiveTexture(GL_TEXTURE4);
    glBindTexture(GL_TEXTURE_2D, command.material.diffuseTexture);
    glActiveTexture(GL_TEXTURE5);
    glBindTexture(GL_TEXTURE_2D, command.material.specularTexture);
    glActiveTexture(GL_TEXTURE6);
    glBindTexture(GL_TEXTURE_2D, command.material.alphaMaskTexture);

    if (command.type == CommandType2D::Outline)
    {
        glDrawArrays(GL_LINE_LOOP, 0, 4);
    }
    else
    {
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr);
    }
}

void Renderer::Renderer_PresentFrame()
{
    SDL_GL_SwapWindow(window);
}

void Renderer::Renderer_ttf(
    const std::string& text,
    TTF_Font* font,
    SDL_Rect* source,
    SDL_Rect* destination,
    SDL_Color& textColour)
{
    (void)source;
    if (font == nullptr || text.empty())
    {
        return;
    }

    SDL_Surface* textSurface = TTF_RenderUTF8_Blended(font, text.c_str(), textColour);
    if (textSurface == nullptr)
    {
        return;
    }

    const unsigned int textTexture = uploadSurfaceTexture(textSurface);
    const int width = destination != nullptr ? destination->w : textSurface->w;
    const int height = destination != nullptr ? destination->h : textSurface->h;
    const int x = destination != nullptr ? destination->x : 0;
    const int y = destination != nullptr ? destination->y : 0;
    SDL_FreeSurface(textSurface);

    if (textTexture == 0)
    {
        return;
    }

    Transform2D transform;
    transform.setPosition({x + width * 0.5f, y + height * 0.5f});
    transform.setScale({width * 0.5f, height * 0.5f});

    Material2DRenderState material;
    material.albedoTexture = textTexture;
    material.lit = false;
    material.renderLayer = 10000;

    renderCommands2D.push_back({
        CommandType2D::Quad,
        transform,
        material,
        nextSubmissionOrder++,
        true
    });
}

bool Renderer::SetWindowFullscreen(
    bool enabled
)
{
    if (window == nullptr)
    {
        return false;
    }

    const Uint32 flags =
        enabled
            ? SDL_WINDOW_FULLSCREEN_DESKTOP
            : 0;

    if (
        SDL_SetWindowFullscreen(
            window,
            flags
        ) != 0
    )
    {
        std::fprintf(
            stderr,
            "Unable to change fullscreen mode: %s\n",
            SDL_GetError()
        );

        return false;
    }

    windowFullscreen = enabled;
    return true;
}

bool Renderer::IsWindowFullscreen() const
{
    return windowFullscreen;
}

bool Renderer::initialise3DRenderer()
{
    meshShader =
        std::make_unique<Shader>();

    meshOutlineShader =
        std::make_unique<Shader>();

    const bool meshLoaded =
        meshShader->loadFromFiles(
            "res/shaders/mesh3d.vert",
            "res/shaders/mesh3d.frag"
        );

    const bool outlineLoaded =
        meshOutlineShader->loadFromFiles(
            "res/shaders/mesh3d_outline.vert",
            "res/shaders/mesh3d_outline.frag"
        );

    return meshLoaded && outlineLoaded;
}

void Renderer::destroy3DRenderer()
{
    renderCommands3D.clear();
    selectionOutlineCommands3D.clear();
    meshShader.reset();
    meshOutlineShader.reset();
}